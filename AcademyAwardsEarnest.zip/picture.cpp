#include "picture.h"

using namespace std;