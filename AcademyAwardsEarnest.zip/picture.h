#pragma once
#ifndef Picture_H
#define Picture_h
#include <string>

using namespace std;

class picture
{
private:
	string name;
	string year;
	string nominations;
	string rating;
	string duration;
	string genre1;
	string genre2;
	string release;
	string metacritic;
	string synopsi;
public:
	//default construct
	picture(){}


	//getters
	string getName() { return name; }
	string getYear() { return year; }
	string getNominations() { return nominations; }
	string getRating() { return rating; }
	string getDuration() { return duration; }
	string getGenre1() { return genre1; }
	string getGenre2() { return genre2; }
	string getRelease() { return release; }
	string getMetacritic() { return metacritic; }
	string getSynopsi() { return synopsi; }

	//setters
	void setName(string x) { name = x; }
	void setYear(string x) { year = x; }
	void setNominations(string x) { nominations = x; }
	void setRating(string x) { rating = x; }
	void setDuration(string x) { duration = x; }
	void setGenre1(string x) { genre1 = x; }
	void setGenre2(string x) { genre2 = x; }
	void setRelease(string x) { release = x; }
	void setMetacritic(string x) { metacritic = x; }
	void setSynopsi(string x) { synopsi = x; }


};


#endif




