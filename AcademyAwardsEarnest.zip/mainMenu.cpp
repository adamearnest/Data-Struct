#include "mainMenu.h"

using namespace std;

void menuOptions::mainMenu()
{
	cout << "Adams Actor Database!" << endl;
	cout << "--------------------------------------" << endl;
	cout << "Main Menu: " << endl;
	cout << "R1 - Read in actors-actress data file and add them to actors-actress list" << endl;
	cout << "R2 - Read in pictures data file and add them to pictures list" << endl;
	cout << "R9 - Save the actors-actress list into a csv file" << endl;
	cout << "R10 - Save pictures list into a csv file" << endl;
	cout << "R11 - Display list of actors-actress on screen" << endl;
	cout << "R12 - Display list of pictures on screen" << endl;
	cout << "Exit- Exit the program" << endl;
	cout << "Select an option in the form r0/R0: ";




};

void menuOptions::selection(string sel)
{
	//check for option 3 and run option 3
	if ((sel == "r1") || (sel == "R1"))
	{		
		r1(sel);
	}

	//check for option 2 and run option 2
	else if ((sel == "r2") || (sel == "R2"))
	{		
		r2(sel);
	}

	//check for option 9 and run option 9
	else if ((sel == "r9") || (sel == "R9"))
	{

		r9(sel);		

	}

	//check for option 10 and run option 10
	else if ((sel == "r10") || (sel == "R10"))
	{
		cout << "Not developed yet" << endl;
		//r10(sel);
	}

	//check for option 11 and run option 11
	else if ((sel == "r11") || (sel == "R11"))
	{		
		r11(sel);
	}

	//check for option 12 and run option 12
	else if ((sel == "r12") || (sel == "R12"))
	{		
		r12(sel);
	}

	//check for exit and change quit bool
	else if ((sel == "Exit") || (sel == "exit"))
	{
		this->quit = true;
	}


	else
	{
		cout << "Option Not Found" << endl;
	}
}


//read files from options
void menuOptions::readData(const string fileName, const string sel)
{	
		//validate filename format
		     //add code here once finished

		//declare file input variable
		ifstream inFile(fileName);

		//check for load type
		if ((sel == "r1") || (sel == "R1"))
		{
			//declare variables to store file values
			string Year, Award, Winner, Name, Film;
			actor actor;

			//store data to actors vector while checking for end of file
			while (!inFile.eof())
			{
				getline(inFile, Year, ',');
				getline(inFile, Award, ',');
				getline(inFile, Winner, ',');
				getline(inFile, Name, ',');
				getline(inFile, Film, '\n');

				actor.setYear(Year);
				actor.setAward(Award);
				actor.setWinner(Winner);
				actor.setName(Name);
				actor.setFilm(Film);

				this->actors.push_back(actor);
			}
		}
		else if ((sel == "r2") || (sel == "R2"))
		{
			string name, year, 
				nominations, rating, 
				duration, genre1, 
				genre2, release, 
				metacritic, synopsi;

			picture pic;

			//store data to actors vector while checking for end of file
			while (!inFile.eof())
			{
				getline(inFile, name, ',');
				getline(inFile, year, ',');
				getline(inFile, nominations, ',');
				getline(inFile, rating, ',');
				getline(inFile, duration, ',');
				getline(inFile, genre1, ',');
				getline(inFile, genre2, ',');
				getline(inFile, release, ',');
				getline(inFile, metacritic, ',');
				getline(inFile, synopsi, '\n');

				pic.setName(name);
				pic.setYear(year);
				pic.setNominations(nominations);
				pic.setRating(rating);
				pic.setDuration(duration);
				pic.setGenre1(genre1);
				pic.setGenre2(genre2);
				pic.setRelease(release);
				pic.setMetacritic(metacritic);
				pic.setSynopsi(synopsi);

				this->pictures.push_back(pic);

			}

		}
		inFile.close();
}

void menuOptions::saveData(const string fileName, const string sel)
{
		//declare file input variable
	ofstream outFile(fileName);

	//check for load type
	if ((sel == "r9") || (sel == "R9"))
	{		
		// actor variable		
		actor actor;
		int count = 0;
		int vectorSize = static_cast<int>(actors.size()-1);

		//store data to actors vector while checking for end of file
		while (count != vectorSize)
		{
			actor.setYear(actors[count].getYear());
			actor.setAward(actors[count].getAward());
			actor.setWinner(actors[count].getWinner());
			actor.setName(actors[count].getName());
			actor.setFilm(actors[count].getFilm());

			outFile << actor.getYear()
				<< ',' << actor.getAward()
				<< ',' << actor.getWinner()
				<< ',' << actor.getName()
				<< ',' << actor.getFilm()
				<< '\n';
			count++;

		}
	}
	else if ((sel == "r10") || (sel == "R10"))
	{
		cout << "Not developed yet" << endl;
	}
}


//option r1
void menuOptions::r1(const string sel)
{
	//declared variables
	string fileName;
	

	//retrieve user imput
	cout << "Please enter your actor file to load: ";
	cin >> fileName;
	//try to read and load from file
	try
	{
		this->readData(fileName, sel);
		cout << "\nFile loading completed \n" << endl;
	}
	catch (...)
	{
		cout << "Error, enter correct file name" << endl;
	}
}

//option r2
void menuOptions::r2(const string sel)
{
	//declared variables
	string fileName;


	//retrieve user imput for file name to load from
	cout << "Please enter your pictures file to load: ";
	cin >> fileName;
	//attempt to read and load from file
	try
	{
		this->readData(fileName, sel);
		cout << "\nFile loading completed \n" << endl;
	}
	catch (...)
	{
		cout << "Error, enter correct file name" << endl;
	}
}

//option r10
void menuOptions::r9(const string sel)
{
	//declared variables
	string fileName;


	//get user imput for file name
	cout << "Please enter your actor file to upload data: ";
	cin >> fileName;

	//attempt to upload
	try
	{
		this->saveData(fileName, sel);
		cout << "\nActor save completed \n" << endl;
	}
	catch (...)
	{
		cout << "Error While saving, option canceled" << endl;
	}
}

void menuOptions::r10(const string)
{

	cout << "Not developed yet" << endl;
}


void menuOptions::r11(const string)
{
	
	cout << "Not developed yet" << endl;
}

void menuOptions::r12(const string)
{
	
	cout << "Not developed yet" << endl;
}