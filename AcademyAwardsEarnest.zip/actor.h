#pragma once
#ifndef Actor_H
#define Actor_H
#include <string>


using namespace std;

class actor
{
private:
	string year;
	string award;
	string winner;
	string name;
	string film;
public:
	//default construct
	actor(){};

	//private memeber getters
	string getYear() { return year; }
	string getAward() { return award; }
	string getWinner() { return winner; }
	string getName() { return name; }
	string getFilm() { return film; }

	//private member setters
	void setYear(string x) { year = x; }
	void setAward(string x) { award = x; }
	void setWinner(string x) { winner = x; }
	void setName(string x) { name = x; }
	void setFilm(string x) { film = x; }
};


#endif 



