
#include "mainMenu.h"

using namespace std;

int main()
{
	menuOptions menu;

	string menuSelection;

	while (true)
	{
		menu.mainMenu();
		cin >> menuSelection;
		menu.selection(menuSelection);

		cout<< "\n\n\n";
		if (menu.getQuit())
			break;
	}


	return 0;
}