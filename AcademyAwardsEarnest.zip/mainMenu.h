#pragma once
#ifndef mainMenu_H
#define mainMenu_H
#include "actor.h"
#include "picture.h"
#include <string>
#include <iostream>
#include <fstream>
#include <vector>
#include <ctype.h>
using namespace std;


class menuOptions
{
private:
	vector<actor> actors;
	vector<picture> pictures;
	bool quit;
public:
	//default constructor
	menuOptions() { quit = false; }

	void mainMenu();

	void selection(const string); //select an option

	void readData(const string, const string);	
  //read data
  
	void saveData(const string, const string); 
  //save data

	//validations	
	bool checkFileName(const string);

	//menu options
	void r1(const string); 
	//load actors-acctress datafile
	
	void r2(const string); 
	//load pictures data to picture list

  //void r3

  //void r4

	//void r5

  //void r6

  //void r7

  //void r8


	void r9(const string); 
	//save actor-actress data to actor csv file
	
	void r10(const string);
	//save pictires to picture csv file
	
	void r11(const string); 
	// display list of actors on screen
	
	void r12(const string); 
	//display list of pictures on screen

	//getter
	bool getQuit() { return quit; }




};
#endif 

